/**
 * Desmos Dark Mode Extension
 * 
 * Simply appends ?invertedColors=true to the URL if not already present.
 * This is the native Desmos way to enable dark mode.
 */

(function() {
    'use strict';
    
    // Get current URL and parameters
    const url = new URL(window.location.href);
    const params = url.searchParams;
    
    // Check if invertedColors is already set
    if (params.get('invertedColors') === 'true') {
        return;
    }
    
    // Calculator pages that support invertedColors
    const calculatorPaths = [
        '/calculator',
        '/3d',
        '/geometry',
        '/scientific',
        '/fourfunction',
        '/matrix'
    ];
    
    const isCalculatorPage = calculatorPaths.some(path => 
        url.pathname === path || url.pathname.startsWith(path + '/')
    );
    
    if (!isCalculatorPage) {
        return;
    }
    
    // Add the parameter and redirect
    params.set('invertedColors', 'true');
    window.location.replace(url.toString());
    
})();
